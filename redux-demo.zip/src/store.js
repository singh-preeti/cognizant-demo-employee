//import { applyMiddleware, createStore } from "redux";
import thunk from "redux-thunk";
import {createStore} from "redux";
import employeeReducer from "./reducers/employee-reducer";
//import { composeWithDevTools } from "redux-devtools-extension";

//const store = createStore(employeeReducer,applyMiddleware(thunk));
const store = createStore(employeeReducer);
export default store;